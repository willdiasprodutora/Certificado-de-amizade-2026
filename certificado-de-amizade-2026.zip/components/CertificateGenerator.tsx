import { GoogleGenAI } from "@google/genai";
import React, { useEffect, useState } from 'react';

interface Props { userName: string; friendName: string; onReset: () => void; }

const loadingMessages = ["Conectando ao Grande Cartório...", "Consultando os astros para 2026...", "Prensando o ouro no pergaminho...", "Verificando a validade do bilhete...", "Colhendo a assinatura oficial..."];

const CertificateGenerator: React.FC<Props> = ({ userName, friendName, onReset }) => {
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentMsgIndex, setCurrentMsgIndex] = useState(0);

  useEffect(() => {
    let interval: number;
    if (isGenerating) { interval = window.setInterval(() => { setCurrentMsgIndex((prev) => (prev + 1) % loadingMessages.length); }, 2500); }
    return () => clearInterval(interval);
  }, [isGenerating]);

  const generateWithAI = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const prompt = `UM CERTIFICADO DE RENOVAÇÃO DE AMIZADE PARA 2026. LUXO, pergaminho antigo, selo de cera. TEXTO: "Eu ${userName} renovo minha amizade com ${friendName} para 2026." Ass: é verdade esse bilhete.`;
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt }] },
        config: { imageConfig: { aspectRatio: "3:4" } }
      });
      const imagePart = response.candidates?.[0]?.content.parts.find(p => p.inlineData);
      if (imagePart?.inlineData) setGeneratedImageUrl(`data:image/png;base64,${imagePart.inlineData.data}`);
      else throw new Error("Erro na imagem");
    } catch (err) { setError("O Cartório está lotado. Tente novamente."); }
    finally { setIsGenerating(false); }
  };

  useEffect(() => { generateWithAI(); }, [userName, friendName]);

  return (
    <div className="flex flex-col items-center w-full max-w-sm">
      <div className="relative w-full bg-zinc-900 rounded-[1.8rem] overflow-hidden shadow-2xl min-h-[320px] flex items-center justify-center">
        {isGenerating ? (
          <div className="p-6 text-center">
            <div className="h-12 w-12 border-4 border-t-yellow-500 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-zinc-500 text-[9px] uppercase font-black">{loadingMessages[currentMsgIndex]}</p>
          </div>
        ) : error ? (
          <button onClick={generateWithAI} className="bg-yellow-500 text-black px-6 py-2 rounded-xl font-bold">Tentar Novamente</button>
        ) : (
          generatedImageUrl && <img src={generatedImageUrl} className="w-full h-full object-contain" />
        )}
      </div>
      {!isGenerating && generatedImageUrl && (
        <div className="mt-4 w-full flex flex-col gap-2">
          <button onClick={() => { const link = document.createElement('a'); link.href = generatedImageUrl; link.download = 'certificado.png'; link.click(); }} className="w-full bg-yellow-500 text-black font-black py-4 rounded-xl">BAIXAR REGISTRO</button>
          <button onClick={onReset} className="text-[8px] text-zinc-600 uppercase font-black tracking-widest py-2">Novo Amigo</button>
        </div>
      )}
    </div>
  );
};
export default CertificateGenerator;