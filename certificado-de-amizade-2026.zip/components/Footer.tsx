import React, { useState } from 'react';

const Footer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string | null>(null);

  const handleWhatsApp = () => {
    window.open('https://wa.me/5551933800338', '_blank');
  };

  return (
    <footer className="mt-6 w-full max-w-sm">
      <div className="flex flex-col items-center gap-3">
        <div className="flex justify-center gap-5">
          <button 
            onClick={() => setActiveTab(activeTab === 'terms' ? null : 'terms')} 
            className={`text-[9px] uppercase font-black tracking-widest transition-colors ${activeTab === 'terms' ? 'text-yellow-500' : 'text-zinc-600'}`}
          >
            Termos
          </button>
          <button 
            onClick={() => setActiveTab(activeTab === 'privacy' ? null : 'privacy')} 
            className={`text-[9px] uppercase font-black tracking-widest transition-colors ${activeTab === 'privacy' ? 'text-blue-400' : 'text-zinc-600'}`}
          >
            Privacidade
          </button>
          <button 
            onClick={() => setActiveTab(activeTab === 'contact' ? null : 'contact')} 
            className={`text-[9px] uppercase font-black tracking-widest transition-colors ${activeTab === 'contact' ? 'text-green-400' : 'text-zinc-600'}`}
          >
            Contato
          </button>
        </div>

        <div className="w-full min-h-[50px] flex items-center justify-center">
          {!activeTab ? (
            <p className="text-zinc-800 text-[8px] uppercase font-black tracking-[0.3em] text-center">
              © 2026 Cartório Digital S.A.
            </p>
          ) : (
            <div className="w-full animate-fade-in px-4">
              {activeTab === 'terms' && (
                <div className="p-3 bg-yellow-500/5 rounded-xl border border-yellow-500/10 text-center">
                  <p className="text-yellow-500 text-[9px] italic font-bold leading-tight">
                    "Este certificado não garante que seu amigo não vai te dar vácuo no WhatsApp. Amizades verdadeiras não precisam de papel."
                  </p>
                </div>
              )}
              {activeTab === 'privacy' && (
                <div className="p-3 bg-blue-500/5 rounded-xl border border-blue-500/10 text-center">
                  <p className="text-blue-400 text-[9px] italic font-bold">
                    "Seus dados estão protegidos por um dragão imaginário. Não vendemos nomes, só renovamos amizades!"
                  </p>
                </div>
              )}
              {activeTab === 'contact' && (
                <div 
                  onClick={handleWhatsApp}
                  className="p-3 bg-green-500/10 rounded-xl border border-green-500/20 text-center cursor-pointer hover:bg-green-500/20 transition-all group active:scale-95"
                >
                  <p className="text-green-400 text-[8px] font-black uppercase tracking-tight leading-none mb-1">
                    aplicativos sites músicas para homenagear
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-white text-sm font-black tracking-wider">
                      51 93380-0338
                    </span>
                    <div className="bg-green-500 p-1 rounded-full group-hover:animate-bounce">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-black" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                      </svg>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </footer>
  );
};

export default Footer;