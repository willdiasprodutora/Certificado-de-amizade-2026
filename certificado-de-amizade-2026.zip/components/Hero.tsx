import React from 'react';

const Hero: React.FC = () => {
  return (
    <header className="text-center mb-4 flex flex-col items-center animate-fade-in w-full">
      <div className="flex items-center justify-center gap-4 mb-1">
        <div className="relative scale-75">
          <div className="absolute inset-0 bg-yellow-500/20 blur-2xl rounded-full"></div>
          <div className="relative bg-yellow-500 w-16 h-16 rounded-[1.4rem] flex items-center justify-center shadow-[0_10px_30px_rgba(234,179,8,0.2)] border-t-2 border-white/30">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-black" viewBox="0 0 24 24" fill="currentColor">
              <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" />
            </svg>
          </div>
        </div>

        <div className="text-left">
           <p className="text-zinc-500 text-[8px] font-black uppercase tracking-[0.4em]">
            Serviço Digital
          </p>
          <h1 className="text-lg font-bold text-white tracking-tight leading-none">
            Renovação de Amizade
          </h1>
        </div>
      </div>

      <div className="flex items-baseline gap-2">
        <span className="glitter-gold text-5xl font-black italic leading-none">
          2026
        </span>
      </div>
    </header>
  );
};

export default Hero;